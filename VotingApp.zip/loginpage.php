<?php
$username = $_POST['uname'];
$password = $_POST['pwd'];

$conn = mysqli_connect("localhost","root","","votingdb");
$rs=mysqli_query($conn,"select * from user_list where Username='$username' and password='$password'");
$cnt = mysqli_num_rows($rs);
mysqli_close($conn);

if($cnt==0)
{
   echo "Invaild Username / Password";
   include "login.htm";
}
else
  header('location:qn.html');
echo "<a href='home.html'><img src='C:\xampp\htdocs\VotingApp\home_img.png' />Go To Home</a>";
?>