
<?php
$Username = $_POST['uname'];
$age=$_POST['age'];
$password = $_POST['pwd'];
$email_id = $_POST['email'];
if($age >= 18)
{
$conn =mysqli_connect("localhost","root","","votingdb");
mysqli_query($conn,"insert into user_list values('$Username','$age','$email_id','$password')");
echo "<h2>Successfully Registered!!!</h2>";
mysqli_close($conn);
 header('location:questn.html');
}
else
{
echo "<h2>You are not eligible to vote.</h2>";
}

echo "<a href='home.html'><img src='C:\xampp\htdocs\VotingApp\home_img.png' />Go To Home</a>";

?>

