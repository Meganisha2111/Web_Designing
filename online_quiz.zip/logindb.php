<?php
$Username = $_POST['uname'];
$password = $_POST['pwd'];
$emailid = $_POST['email'];
$conn =mysqli_connect("localhost","root","","dblogin");
mysqli_query($conn,"insert into players values('$Username','$password','$emailid')");
echo "<h2>Successfully Added</h2>";
mysqli_close($conn);
include("login.html")
?>