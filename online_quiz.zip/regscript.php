<?php
$username = $_POST['uname'];
$password = $_POST['pwd'];
echo "<h4><center>CONGRATS!!!YOU HAVE SUCCESSFULLY REGISTERED YOURSELF!!!<br><br>
<br>TO PLAY LOGIN...</h4></center>";
include("login.html")
?>