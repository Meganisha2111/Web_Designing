<?php

echo "<h3>CONGRATS!!!YOU ARE SUCCESSFULLY LOGGED IN!!!</h3>";
echo "<center><table width=250 length=10 border=10>
<tr bgcolor='RED'><td><a href='l.html'>START NOW</a></td></center>";
?>


