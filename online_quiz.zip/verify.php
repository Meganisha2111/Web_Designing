<?php
$username = $_POST['uname'];
$password = $_POST['pwd'];

$conn = mysqli_connect("localhost","root","","dblogin");
$rs=mysqli_query($conn,"select * from players where username='$username' and password='$password'");
$cnt = mysqli_num_rows($rs);
mysqli_close($conn);

if($cnt==0)
{
      echo "<center><h3>CONGRATS!!!YOU ARE SUCCESSFULLY LOGGED IN!!!</h3></center>";
      echo "<style type='text/css'>a.nounderline{text-decoration:none;}
      table,td,th{border:5px solid red;padding:5px;}
       td{background-color:blue;color:yellow;}</style>
      <center><table> <tr><td><a href='l.html' class='nounderline'>START NOW</a></td></center></table>";
  }
else
{
     echo "<br><center>Invaild Username / Password</center><br>";
      include ("login.html");
}
 
?>